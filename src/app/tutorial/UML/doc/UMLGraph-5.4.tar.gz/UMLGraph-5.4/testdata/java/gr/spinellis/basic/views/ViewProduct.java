package gr.spinellis.basic.views;

/**
 * @view
 * @opt hide
 * 
 * @match class gr.spinellis.basic.product.* 
 * @opt !hide 
 * @opt attributes
 */
public class ViewProduct {
}
