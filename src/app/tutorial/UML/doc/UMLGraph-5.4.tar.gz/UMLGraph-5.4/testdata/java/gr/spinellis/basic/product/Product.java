package gr.spinellis.basic.product;

/**
 * @assoc * - 1 Category
 */
public class Product {

    public String name;
    public int stock;
    public double price;
    public Category category;

}
