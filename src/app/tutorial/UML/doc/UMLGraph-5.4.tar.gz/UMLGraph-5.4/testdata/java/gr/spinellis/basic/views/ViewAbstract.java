package gr.spinellis.basic.views;

/**
 * @view
 * @opt hide
 *  
 * @match class gr.spinellis.basic.product.* 
 * @opt !hide
 * @match class gr.spinellis.basic.*
 * @opt nodefillcolor LemonChiffon 
 */
public abstract class ViewAbstract {
}


