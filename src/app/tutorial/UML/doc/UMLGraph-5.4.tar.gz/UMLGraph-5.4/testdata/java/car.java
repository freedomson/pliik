// $Id$
class Tyre {}
class Engine {}
class Body {}

/**
 * @composed 1 - 4 Tyre
 * @composed 1 - 1 Engine
 * @composed 1 - 1 Body
 */
class Car {}
